package labo2.protocol;

import java.io.IOException;

public class ResolverClientException extends IOException {
	public ResolverClientException(String message) {
		super(message);
	}
}
