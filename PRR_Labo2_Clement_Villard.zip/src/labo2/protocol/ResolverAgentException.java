package labo2.protocol;

import java.io.IOException;

public class ResolverAgentException extends IOException {
	public ResolverAgentException(String message) {
		super(message);
	}
}
