package labo2.resolver;

public enum State {
	SYNC,
	READY
}
